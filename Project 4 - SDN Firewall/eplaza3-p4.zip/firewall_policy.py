#!/usr/bin/python
# CS 6250 Summer 2019 - Project 4 - SDN Firewall

from pyretic.lib.corelib import *
from pyretic.lib.std import *
from pyretic.lib.query import packets
from pyretic.core import packet


def make_firewall_policy(config):

    # You may place any user-defined functions in this space.
    # You are not required to use this space - it is available if needed.

    # feel free to remove the following "print config" line once you no longer need it
    #print config  # for demonstration purposes only, so you can see the format of the config

    # This stores all of the policies that will be sent to Pyretic.  It is a list.
    rules = []

    for entry in config:

        # TODO - This is where you build your firewall rules...
        # Note that you will need to delete the rule line below when you create your own
        # firewall rules.  Refer to the Pyretic github documentation for instructions on how to
        # format these commands.
        # Example (but incomplete)
        # rule = match(srcport = int(entry['port_src']))
        # The line below is hardcoded to match TCP Port 1080.  You must remove this line
        # in your completed assignments.  Do not hardcode your solution - you must use items
        # in the entry[] dictionary object to build your final ruleset for each line in the
        # policy file.

        # Delete this line when you build your implementation.
        # rule = match(dstport=1080, ethtype=packet.IPV4, protocol=packet.TCP_PROTO)
        udp_rule, tcp_rule, icmp_rule = match_firewall_rule(entry)
        if udp_rule:
            rules.append(udp_rule)
        if tcp_rule:
            rules.append(tcp_rule)
        if icmp_rule:
            rules.append(icmp_rule)
        pass

    allowed = ~(union(rules))

    return allowed


NO_MATCH = '-'


def match_firewall_rule(entry):
    f_rule = format_rule(entry)

    if dont_match(f_rule):
        return None, None, None

    # Matching Protocol Rules
    udp_rule = match_udp(f_rule)
    tcp_rule = match_tcp(f_rule)
    icmp_rule = match_icmp(f_rule)

    # Matching Mac, IP, Port rules
    mac_rule = match_mac(f_rule)
    ip_rule = match_ip(f_rule)
    port_rule = match_port(f_rule)

    # Combining Protocol, Mac, Ip, and Port Rules with Protocol

    if udp_rule:
        udp_rule = combine_protocol_mac_ip_port(
            udp_rule, mac_rule, ip_rule, port_rule)

    if tcp_rule:
        tcp_rule = combine_protocol_mac_ip_port(
            tcp_rule, mac_rule, ip_rule, port_rule)

    if icmp_rule:
        icmp_rule = combine_protocol_mac_ip_port(
            icmp_rule, mac_rule, ip_rule, port_rule)

    return udp_rule, tcp_rule, icmp_rule


def combine_protocol_mac_ip_port(p_rule, mac_rule, ip_rule, port_rule):
    if mac_rule:
        p_rule = p_rule & mac_rule
    if ip_rule:
        p_rule = p_rule & ip_rule
    if port_rule:
        p_rule = p_rule & port_rule
    return p_rule


def format_rule(entry):
    del entry['rulenum']
    return entry


def dont_match(entry):
    return all(value == NO_MATCH for value in entry.values())


def match_mac(entry):
    mac_src = entry['macaddr_src']
    mac_dest = entry['macaddr_dst']

    if mac_src != NO_MATCH and mac_dest != NO_MATCH:
        return match(srcmac=EthAddr(mac_src), dstmac=EthAddr(mac_dest))

    if mac_src != NO_MATCH:
        return match(srcmac=EthAddr(mac_src))

    if mac_dest != NO_MATCH:
        return match(dstmac=EthAddr(mac_dest))

    return None


def match_udp(entry):
    if entry['protocol'] == 'U' or entry['protocol'] == 'B':
        return match(ethtype=packet.IPV4, protocol=packet.UDP_PROTO)
    return None


def match_tcp(entry):
    if entry['protocol'] == 'T' or entry['protocol'] == 'B':
        return match(ethtype=packet.IPV4, protocol=packet.TCP_PROTO)
    return None


def match_icmp(entry):
    if entry['protocol'] == 'I':
        return match(ethtype=packet.IPV4, protocol=packet.ICMP_PROTO)
    return None


def match_ip(entry):
    ip_src = entry['ipaddr_src']
    ip_dest = entry['ipaddr_dst']

    if ip_src != NO_MATCH and ip_dest != NO_MATCH:
        return match(srcip=IPAddr(ip_src), dstip=IPAddr(ip_dest))

    if ip_src != NO_MATCH:
        return match(dstip=IPAddr(ip_src))

    if ip_dest != NO_MATCH:
        return match(dstip=IPAddr(ip_dest))

    return None


def match_port(entry):
    src_port = entry['port_src']
    dest_port = entry['port_dst']

    if src_port != NO_MATCH and dest_port != NO_MATCH:
        return match(srcport=int(src_port), dstport=int(dest_port))

    if src_port != NO_MATCH:
        return match(srcport=int(src_port))

    if (dest_port != NO_MATCH):
        return match(dstport=int(dest_port))

    return None
