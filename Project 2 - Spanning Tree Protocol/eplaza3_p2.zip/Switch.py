# Project 2 for OMS6250
#
# This defines a Switch that can can send and receive spanning tree
# messages to converge on a final loop free forwarding topology.  This
# class is a child class (specialization) of the StpSwitch class.  To
# remain within the spirit of the project, the only inherited members
# functions the student is permitted to use are:
#
# self.switchID                   (the ID number of this switch object)
# self.links                      (the list of swtich IDs connected to this switch object)
# self.send_message(Message msg)  (Sends a Message object to another switch)
#
# Student code MUST use the send_message function to implement the algorithm -
# a non-distributed algorithm will not receive credit.
#
# Student code should NOT access the following members, otherwise they may violate
# the spirit of the project:
#
# topolink (parameter passed to initialization function)
# self.topology (link to the greater topology structure used for message passing)
#
# Copyright 2016 Michael Brown, updated by Kelly Parks
#           Based on prior work by Sean Donovan, 2015

from Message import *
from StpSwitch import *


class Switch(StpSwitch):

    def __init__(self, idNum, topolink, neighbors):
        super(Switch, self).__init__(idNum, topolink, neighbors)
        self.node = SwitchDSNode(idNum, neighbors)

    # P2Notes: Implement the Spanning Tree Protocol
    # by writing code that sends the initial messages
    # to neighbors of the switch...

    def send_initial_messages(self):
        for destinationID in self.node.get_active_links():
            self.send_message(
                Message(self.node.get_current_root(), self.node.get_root_distance(), self.switchID, destinationID, False))

    # P2Notes: ...and processes a message from an immediate neighbor

    def process_message(self, message):
        current_root = self.node.get_current_root()
        message_root =  message.root
        # P2Notes: The switch will update the root stored in the data structure
        # if the switch receives a message with a root of a lower ID
        if current_root > message_root:
            self.update_switch_properties(message)
        elif current_root == message_root:
            new_distance = (message.distance + 1)
            current_distance = self.node.get_root_distance()
            # P2Notes: ... or if there is a tiebreaker situation that indicates a shorter path to the root.
            if current_distance == new_distance:
                self.break_tie(message)
            # Shorter distance found. So, activeLinks, distance, and neigbor have to be updated
            elif current_distance > new_distance:
                self.update_switch_properties(message, False)
             # Second, if the switch receives a message with pathThrough = True
             # but the switch did not have that originID in its activeLinks list,
             # so the switch must add originID to the activeLinks list or if the switch receives
             # a message with paththrough = False but the switch has that originID in its activeLinks
             # so it needs to remove originID from the activeLinks list.
            elif current_distance < new_distance:
                self.update_links_pathThrough(message)

    # Second, if the switch receives a message with pathThrough = True
    # but the switch did not have that originID in its activeLinks list,
    # so the switch must add originID to the activeLinks list or if the switch receives
    # a message with paththrough = False but the switch has that originID in its activeLinks
    # so it needs to remove originID from the activeLinks list.

    def update_links_pathThrough(self, message):
        self.node.update_active_links(message.origin, message.pathThrough)
    # P2Notes: Tie breakers:
    # All ties will be broken by lowest switch ID,
    # meaning that if a switch has multiple paths to the root at the same length,
    # it will select the path through the lowestid neighbor.
    # For example, assume switch 5 has two paths to the root, through switch 3 and switch 2.
    # Assume further each path is 2 hops in length, then switch 5 will select switch 2
    # as the path to the root and disable forwarding on the link to switch 3

    def break_tie(self, message):
        single_neighor = self.node.get_visit_neighbor()
        origin_switch = message.origin
        if single_neighor != origin_switch:
            self.node.update_active_links(
                max(single_neighor, origin_switch), False)
            if single_neighor > origin_switch:
                self.node.set_visited_neighbor(origin_switch)
        self.send_new_messages()

    # P2Notes: The switch will update the root stored in the data structure
    # if the switch receives a message with a root of a lower ID

    def update_switch_properties(self, message, updateRoot=True):
        if updateRoot:
            self.node.set_current_root(message.root)
        origin_switch = message.origin
        self.node.set_root_distance(message.distance + 1)
        self.node.update_active_links(origin_switch)
        self.node.set_visited_neighbor(origin_switch)
        self.send_new_messages()

    # When sending out messages, pathThrough should only be True
    # if the destinationID switch is the neighbor
    # that the switch with ID of originID goes through to get to the root.
    # For example, if switchID 6 goes through neighbor with switchID 9
    # to get to the root, then the message from switch 6 to switch 9 would be originID= 6,
    # destinationID = 9, pathThrough = True. And the messages to the other neighbors of switchID 6
    # would have pathThrough = False. Each switch only goes through one neighbor to get to the root.

    def send_new_messages(self):
        for link in self.links:
            passing = True if link == self.node.get_visit_neighbor() else False
            self.send_message(Message(self.node.get_current_root(),
                                      self.node.get_root_distance(), self.switchID, link, passing))

    def generate_logstring(self):
        single_neighor = self.node.get_visit_neighbor()
        if single_neighor:
            self.node.update_active_links(single_neighor)
        out = ''
        sorted_links = sorted(self.node.get_active_links())
        linkSize = len(sorted_links)
        for i in range(linkSize):
            link = sorted_links[i]
            out += '{0} - {1}'.format(self.switchID, link)
            if i < linkSize - 1:
                out += ', '
        return out


# P2Notes: An example data structure would include, at a minimum,
# a variable to store the switchID that this switch currently sees as the root,
# a variable to store the distance to the switch root,
# and a list or other datatype that stores the active links
# (i.e., the links to neighbors that should be drawn in the spanning tree)
# ...
# The switches are trying to learn the root,
# or the switch with the lowest id and the path to the switch.
# To track the path to the root, each switch may need to know which neighbor
# it goes through to get there and the distance of the path to the root.


class SwitchDSNode:
    def __init__(self, rootID, links):
        self.rootSwitchID = rootID
        self.rootDistance = 0
        self.activeLinks = set(links)
        self.visitNeighbor = None

    def get_current_root(self):
        return self.rootSwitchID

    def set_current_root(self, rootID):
        self.rootSwitchID = rootID

    def get_root_distance(self):
        return self.rootDistance

    def set_root_distance(self, rootDistance):
        self.rootDistance = rootDistance

    def get_visit_neighbor(self):
        return self.visitNeighbor

    def set_visited_neighbor(self, visitNeighbor):
        self.visitNeighbor = visitNeighbor

    def get_active_links(self):
        return self.activeLinks

    def update_active_links(self, link, add=True):
        if add:
            self.activeLinks.add(link)
        else:
            self.activeLinks.discard(link)
